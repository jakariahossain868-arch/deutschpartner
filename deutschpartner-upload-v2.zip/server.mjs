import http from "node:http";
import { readFileSync, existsSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { extname, join, normalize, sep } from "node:path";
import { system, LEVELS } from "./prompt.mjs";
import { CORR_SCHEMA, correctionPrompt, clean } from "./correct.mjs";
try { for (const l of readFileSync(".env", "utf8").split("\n")) { const m = l.match(/^([A-Z_]+)=(.*)$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].trim(); } } catch {}
const E = process.env, BASE = E.OPENAI_BASE || "https://api.openai.com", KEY = E.OPENAI_API_KEY, GEM = E.GEMINI_API_KEY, GBASE = E.GEMINI_BASE || "https://generativelanguage.googleapis.com/v1beta/openai", PORT = +E.PORT || 8080;
const LIM = { chat: +E.RATE_CHAT || 30, token: +E.RATE_TOKEN || 6 }, hits = new Map();
const limited = (ip, k, max) => { const now = Date.now(), a = (hits.get(ip + k) || []).filter(t => now - t < 60000); a.push(now); hits.set(ip + k, a); return a.length > max; };
const cors = E.ALLOWED_ORIGIN ? { "Access-Control-Allow-Origin": E.ALLOWED_ORIGIN, "Access-Control-Allow-Headers": "Content-Type", "Vary": "Origin" } : {};
const SEC = { "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Permissions-Policy": "microphone=(self), camera=()", "X-Frame-Options": "DENY",
  "Content-Security-Policy": `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self' https://api.openai.com ${E.CSP_CONNECT || ""}; frame-ancestors 'none'; base-uri 'none'` };
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.length || now - a[a.length - 1] > 60000) hits.delete(k); }, 60000).unref();
const out = (res, code, o) => { res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store", ...SEC, ...cors }); res.end(JSON.stringify(o)); };
const body = req => new Promise((ok, no) => { let s = ""; req.on("data", c => { s += c; if (s.length > 20000) { s = ""; no(new Error("big")); } }); req.on("end", () => { try { ok(JSON.parse(s || "{}")); } catch (e) { no(e); } }); });
const oa = (path, b, ip) => fetch(BASE + path, { method: "POST", headers: { Authorization: "Bearer " + KEY, "Content-Type": "application/json", "OpenAI-Safety-Identifier": createHash("sha256").update(ip).digest("hex").slice(0, 32) }, body: JSON.stringify(b) });
// Text AI: OpenAI if its key is set, otherwise free Gemini (OpenAI-compatible endpoint)
const FREE = !KEY && Boolean(GEM);
const llm = (body, ip) => FREE
  ? fetch(GBASE + "/chat/completions", { method: "POST", headers: { Authorization: "Bearer " + GEM, "Content-Type": "application/json" }, body: JSON.stringify({ ...body, model: E.TEXT_MODEL || "gemini-flash-lite-latest", max_tokens: 1500 }) })
  : oa("/v1/chat/completions", body, ip);
const okTopic = t => typeof t === "string" && t.length > 0 && t.length <= 60;
const ALLOW = new Set(["index.html", "app.js", "app.css", "manifest.webmanifest", "sw.js", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png"]);
const MIME = { ".webmanifest": "application/manifest+json", ".svg": "image/svg+xml", ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".png": "image/png" };
http.createServer(async (req, res) => {
  const ip = req.socket.remoteAddress || "x", url = new URL(req.url, "http://x");
  if (req.method === "OPTIONS") { res.writeHead(204, { ...cors, "Access-Control-Allow-Methods": "POST" }); return res.end(); }
  try {
    if (req.method === "POST" && url.pathname === "/api/chat") {
      if (!KEY && !GEM) return out(res, 503, { error: "no_key" });
      if (limited(ip, "chat", LIM.chat)) return out(res, 429, { error: "rate" });
      const { messages = [], level, topic } = await body(req);
      if (!LEVELS[level] || !okTopic(topic) || !Array.isArray(messages) || messages.length > 40 || messages.some(m => !["user", "assistant"].includes(m.role) || typeof m.content !== "string" || m.content.length > 1000)) return out(res, 400, { error: "bad" });
      const hist = messages.length ? messages : [{ role: "user", content: "(Beginne das Gespräch.)" }];
      const r = await llm({ model: E.TEXT_MODEL || "gpt-4.1-mini", max_tokens: 150, messages: [{ role: "system", content: system(level, topic, !messages.length) }, ...hist] }, ip);
      if (!r.ok) return out(res, 502, { error: "upstream", status: r.status });
      const j = await r.json(); return out(res, 200, { text: j.choices?.[0]?.message?.content?.trim() || "" });
    }
    if (req.method === "POST" && url.pathname === "/api/token") {
      if (!KEY) return out(res, GEM ? 501 : 503, { error: GEM ? "no_realtime" : "no_key" });
      if (limited(ip, "token", LIM.token)) return out(res, 429, { error: "rate" });
      const { level, topic } = await body(req);
      if (!LEVELS[level] || !okTopic(topic)) return out(res, 400, { error: "bad" });
      const r = await oa("/v1/realtime/client_secrets", { expires_after: { anchor: "created_at", seconds: 120 }, session: { type: "realtime", model: E.REALTIME_MODEL || "gpt-realtime", instructions: system(level, topic, true), audio: { input: { transcription: { model: "gpt-4o-mini-transcribe", language: "de" }, turn_detection: { type: "semantic_vad" } }, output: { voice: "marin" } } } }, ip);
      if (!r.ok) return out(res, 502, { error: "upstream", status: r.status });
      const j = await r.json(); return out(res, 200, { value: j.value, expires_at: j.expires_at });
    }
    if (req.method === "POST" && url.pathname === "/api/correct") {
      if (!KEY && !GEM) return out(res, 503, { error: "no_key" });
      if (limited(ip, "chat", LIM.chat)) return out(res, 429, { error: "rate" });
      const { sentence, level, context = "" } = await body(req);
      if (!LEVELS[level] || typeof sentence !== "string" || !sentence.trim() || sentence.length > 300 || typeof context !== "string" || context.length > 300) return out(res, 400, { error: "bad" });
      const r = await llm({ model: E.TEXT_MODEL || "gpt-4.1-mini", max_tokens: 800, response_format: FREE ? { type: "json_object" } : { type: "json_schema", json_schema: { name: "correction", strict: true, schema: CORR_SCHEMA } }, messages: [{ role: "system", content: correctionPrompt(level) + (FREE ? "\nAntworte NUR mit einem JSON-Objekt dieser Form: " + JSON.stringify(CORR_SCHEMA.properties) : "") }, { role: "user", content: `Letzte Frage der KI: ${context}\nSatz der Person: ${sentence}` }] }, ip);
      if (!r.ok) return out(res, 502, { error: "upstream", status: r.status });
      let c; try { c = JSON.parse((await r.json()).choices[0].message.content); } catch { return out(res, 502, { error: "format" }); }
      return out(res, 200, clean(c, level, sentence.trim()));
    }
    if (req.method === "GET" && url.pathname === "/api/config") return out(res, KEY || GEM ? 200 : 503, { realtime: Boolean(KEY) });
    if (req.method === "GET") {
      const name = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
      const f = ALLOW.has(name) ? [join("dist", name), name].find(x => existsSync(x) && statSync(x).isFile()) : null;
      if (f) { res.writeHead(200, { "Content-Type": MIME[extname(f)] || "application/octet-stream", "Cache-Control": "no-cache, must-revalidate", ...SEC }); return res.end(readFileSync(f)); }
    }
    out(res, 404, { error: "not_found" });
  } catch { out(res, 400, { error: "bad" }); }
}).listen(PORT, () => console.log("Server on :" + PORT + (KEY ? " [OpenAI Realtime]" : GEM ? " [FREE: Gemini + Browser-Stimme]" : " (OPENAI_API_KEY oder GEMINI_API_KEY fehlt!)")));
