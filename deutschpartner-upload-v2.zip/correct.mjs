export const CATS = ["Artikel", "Verbposition", "Konjugation", "Perfekt", "Kasus", "Präposition", "Wortstellung", "Plural", "Adjektivendung", "Modalverb", "Nebensatz", "Rechtschreibung", "Wortwahl", "Sonstiges"];
export const MAX = { A2: 2, B1: 2, B2: 3, C1: 3 };
const S = { type: "string" }, obj = p => ({ type: "object", properties: p, required: Object.keys(p), additionalProperties: false });
export const CORR_SCHEMA = obj({
  has_errors: { type: "boolean" }, corrected: S, bn: S,
  mistakes: { type: "array", items: obj({ cat: { type: "string", enum: CATS }, bn: S, rule: S }) },
  grammar: obj({ article: S, verb: S, structure: S }), natural: S, example: obj({ de: S, bn: S }),
  words: { type: "array", items: obj({ de: S, bn: S }) },
});
export const correctionPrompt = level => `Du bist ein erfahrener, freundlicher Deutschlehrer für Bengali-Sprecher. Analysiere NUR den Satz der Person (Niveau ${level}). Antworte als JSON nach Schema.
Regeln: Korrigiere echte Fehler (Artikel, Kasus, Konjugation, Perfekt, Wortstellung, Präposition, Plural, Adjektivendung, Nebensatz). Ignoriere Groß-/Kleinschreibung, Satzzeichen und Füllwörter (äh, hm), weil der Text aus Spracherkennung kommen kann. Behalte die Bedeutung bei.
Sortiere "mistakes" nach Wichtigkeit (wichtigster Fehler zuerst), höchstens ${MAX[level]}. ${level === "A2" ? "A2: nur die 1–2 wichtigsten Fehler, sehr einfache Erklärung." : level === "C1" ? "C1: auch Stil und feine Nuancen erwähnen." : ""}
Alle Erklärungen (bn, rule, grammar.*) auf einfachem BENGALI; deutsche Wörter im Original. "bn" ist die bengalische Übersetzung des korrigierten Satzes. "grammar": kurze bengalische Hinweise zum richtigen Artikel, Verb und Satzbau in DIESEM Satz (leer, wenn nicht relevant). "natural": natürlichere Formulierung (gleich, wenn schon natürlich). "example": ein kurzer neuer Beispielsatz zur gleichen Regel + Bengali. "words": bis zu 3 nützliche Wörter. Wenn kein Fehler: has_errors=false, mistakes=[], corrected=Originalsatz.`;
const str = (x, n = 400) => (typeof x === "string" ? x.slice(0, n) : "");
export function clean(c, level, sentence) {
  const ms = (Array.isArray(c.mistakes) ? c.mistakes : []).slice(0, MAX[level]).map(m => ({ cat: CATS.includes(m?.cat) ? m.cat : "Sonstiges", bn: str(m?.bn), rule: str(m?.rule) }));
  const has = Boolean(c.has_errors) && ms.length > 0, g = c.grammar || {}, e = c.example || {};
  return { has_errors: has, original: sentence, corrected: has ? str(c.corrected, 300) || sentence : sentence, bn: str(c.bn), mistakes: has ? ms : [],
    grammar: { article: str(g.article), verb: str(g.verb), structure: str(g.structure) }, natural: str(c.natural, 300), example: { de: str(e.de, 200), bn: str(e.bn, 200) },
    words: (Array.isArray(c.words) ? c.words : []).slice(0, 3).map(w => ({ de: str(w?.de, 60), bn: str(w?.bn, 80) })).filter(w => w.de) };
}
